<!-- Footer START  -->  
<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="socialMedia">
                    <ul class=" list-inline text-center">

                        <li class="facebook">
                            <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li class="twitter">
                            <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li class="google-plus">
                            <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                        </li>
                        <li class="linkedin">
                            <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                        <li class="youtube cboxElement">
                            <a target="_blank" href="#"><i class="fa fa-youtube-play"></i></a>
                        </li>
                    </ul>
                </div>
            </div>            
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="footer_links text-center">
                    <ul class=" list-inline text-center">
                        <li>
                          <a href="index.php" class="hover_001 after" > الرئيسية </a>
                        </li>
                        <li>
                            <a href="results_car.php" class="hover_001 after"> نتيجة البحث </a>
                        </li>
                        <li>
                          <a href="car_details_page.php" class="hover_001 after"> التفاصيل </a>
                        </li> 
                        <li>
                          <a href="booking_page.php" class="hover_001 after"> الحجز </a>
                        </li> 
                        <li>
                          <a href="contact_us.php" class="hover_001 after"> تواصل معنا  </a>
                        </li>
                        <li>
                          <a href="about_us.php" class="hover_001 after"> عن الموقع </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-push-3">
                <div class="copyRights text-center">
                    <p> Copyright © 2017 . All rights reserved. </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Footer END  -->  
  
    
    
    
<script src="js/jquery-1.11.3.min.js"></script>	
<script src="js/bootstrap.min.js"></script> 
<script src="js/html5shiv.min.js"></script>		

<!-- Date Range Picker Scripts START -->  
<!--Script Navbar fixed : START-->
<script>
$(window).scroll(function() {
    if($(this).scrollTop()>50) {
        $( ".navbar-me" ).addClass("fixed-me");
    } else {
        $( ".navbar-me" ).removeClass("fixed-me");
    }
});
</script>
<!--Script Navbar fixed : END-->
<script type="text/javascript" src="js/date_picker/jquery-ui.js"></script>  <!-- Date Range Picker -->  
<script type="text/javascript" src="js/date_picker/date-range-picker.js"></script>  <!-- Date Range Picker -->  
    <script>
        $( document ).ready(function() {
            makedatepicker();
        });
        var drp; 
        function makedatepicker(){
            drp = $("#myDate1").datepicker({}),
            drp = $("#myDate2").datepicker({});
        }
    </script>
<!-- Date Range Picker Scripts END -->  
    
<!-- Time Picker Scripts START -->  
<script src="js/time_picker/timepicki.js"></script>
    <script>
	$('#timepicker1').timepicki();
    $('#timepicker2').timepicki();
    </script>
<!-- Time Picker Scripts END --> 
    
    
<!--Carousel Script start -->
    <script src="js/owl.carousel.js"></script>
    <script>
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:20,
            dots:true,
            nav:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:4
                }
            }
        })
    </script>
<!-- Carousel Script end -->

<!-- Remove Script in Profile Page START-->
<script>
    $('.remove').on('click', function(){
    $(this).parent().parent().remove();
});
</script>
<!-- Remove Script in Profile Page END-->

<!-- Show Password Script in Profile Page START-->
<script src="js/bootstrap-show-password.js"></script>
<script>
    $(function() {
        $('#password').password().on('show.bs.password', function(e) {
            $('#eventLog').text('On show event');
            $('#methods').prop('checked', true);
        }).on('hide.bs.password', function(e) {
                    $('#eventLog').text('On hide event');
                    $('#methods').prop('checked', false);
                });
        $('#methods').click(function() {
            $('#password').password('toggle');
        });
    });
</script>
<!-- Show Password Script in Profile Page END-->

<!-- International Phone Number Input Script in SignUP Page START-->
  <script src="js/international_phone/intlTelInput.js"></script>
  <script>
    $("#phone").intlTelInput({
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: "body",
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
      // hiddenInput: "full_number",
      // initialCountry: "auto",
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
       separateDialCode: true,
      utilsScript: "js/international_phone/utils.js"
    });
  </script>
<!-- International Phone Number Input Script in SignUP Page END-->


</body>

</html>
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<!-- I.X -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile -->

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content=" موقع EZ-ajar تصميم وتطوير شركة عرب نيو تك لخخدمات الويب المتكاملة ">
		<title> AZ-ajar </title>
		<link rel="stylesheet" href="css/bootstrap.css">
    <!-- Google Fonts 'Raleway font' -->
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="css/bootstrap-rtl.css">
    <!-- Date Range Picker -->
        <link rel="stylesheet" href="css/date_picker/jquery-ui.css">
        <link rel="stylesheet" href="css/date_picker/date-range-picker.css">
    <!-- Time Picker -->
    <link href="css/time_picker/timepicki.css" rel="stylesheet">
    <!-- Carousel css -->  
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- Font awesome -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- My Style -->
		<link rel="stylesheet" href="css/style.css" type="text/css"/>	
		<script src="js/html5shiv.min.js"></script>		
</head>
<body>
    

<!--  Header START  -->  
<section class="fristBar">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-4 col-xs-7">
                <div class="login_signUp">
                    <a href="my-account.php"> <i class="fa fa-user" aria-hidden="true"></i> البروفايل </a>
                </div>
            </div>
            <div class="col-md-1 col-xs-6">
                <div class="">

                </div>
            </div>
            <div class="col-md-7 col-xs-12">
                <div class="phone_num text-center">
                    <p>Contact Us: info@EZajar.com</p>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-5">
                <ul class="selectLanguage ">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle select_language_0" data-toggle="dropdown" role="button" aria-expanded="false">
                            <img src="img/arabic.jpg" class="language_img" alt="" /> العربية
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="../EN//index.php" class="language_00"><img src="img/English.png" alt="English" /> English </a></li>
                            <li><a href="../../AR" class="language_00"><img src="img/arabic.jpg" alt="Arabic" /> العربية</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

    </div>
</section>  
<!-- Header END  -->  
    
<!-- Nav_bar_cust END  -->  
<section class="nav_bar_cust">  
    <nav class="navbar custom-navbar navbar-me" role="navigation">
      <div class="container">
        <!-- expanded behavior -->
        <div class="navbar-header">
          <a href="index.php"><img src="img/logo.png" class="img-responsive" alt=""/></a>

          <!-- expanded right navbar -->
          <div class="navbar-right">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#right-navbar-menu">
                <i class="fa fa-bars" aria-hidden="false"></i>
            </button>
          </div>
        </div>

        <ul id="right-navbar-menu" class="nav navbar-nav navbar-right navbar-collapse collapse wrapper">
            <li>
              <a href="index.php" class="hover_001 after" > الرئيسية </a>
            </li>
            <li>
              <a href="results_car.php" class="hover_001 after"> نتيجة البحث </a>
            </li>
            <li>
              <a href="car_details_page.php" class="hover_001 after"> التفاصيل </a>
            </li> 
            <li>
              <a href="booking_page.php" class="hover_001 after"> الحجز </a>
            </li> 
            <li>
              <a href="contact_us.php" class="hover_001 after"> تواصل معنا  </a>
            </li>
            <li>
              <a href="about_us.php" class="hover_001 after"> عن الموقع </a>
            </li>
            
        </ul>

      </div>
    </nav>
</section>
<!-- Nav_bar_cust END  -->  